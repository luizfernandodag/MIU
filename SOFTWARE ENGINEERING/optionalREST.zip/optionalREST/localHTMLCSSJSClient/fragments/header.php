<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <a style="padding-right: 2em;" class="navbar-brand" href="../index.html">eRegistrar : : : a
            Student-Class Management system</a>
        <!--<span style="color: #ffffff;"> &nbsp; | &nbsp;</span>-->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01"
                aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item" style="border-left: white 1px solid; padding-left: 2em; padding-right: 2em;">
                    <a class="nav-link" href="student/list">Students</a>
                </li>
                <li class="nav-item" style="border-left: white 1px solid; padding-left: 2em;">
                    <a class="nav-link" href="student/list">Classroom</a>
                </li>
                <li class="nav-item" style="border-left: white 1px solid; padding-left: 2em;">
                    <a class="nav-link" href="student/list">Transcript</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <span style="color: #ffffff;">Welcome,&nbsp;</span>
                <a style="color: #ffffff; margin-right: 1em;" href="#">Guest</a>
                <a href="#" class="btn btn-secondary">Sign In</a>
            </form>
        </div>
    </nav>
</header>