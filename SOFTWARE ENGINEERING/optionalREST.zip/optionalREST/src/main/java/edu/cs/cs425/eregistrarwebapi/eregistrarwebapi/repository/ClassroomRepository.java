package edu.cs.cs425.eregistrarwebapi.eregistrarwebapi.repository;


import edu.cs.cs425.eregistrarwebapi.eregistrarwebapi.model.*;
import org.springframework.data.repository.CrudRepository;


public interface ClassroomRepository extends CrudRepository<Classroom, Integer> {

}
