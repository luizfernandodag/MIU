package edu.miu.cs.cs425.demowebapps.elibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab7ElibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
