package edu.miu.cs.cs425.demowebapps.elibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab7ElibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab7ElibraryApplication.class, args);
	}

}
