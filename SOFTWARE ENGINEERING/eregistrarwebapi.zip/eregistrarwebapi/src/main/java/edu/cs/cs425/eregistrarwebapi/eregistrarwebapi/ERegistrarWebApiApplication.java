package edu.cs.cs425.eregistrarwebapi.eregistrarwebapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ERegistrarWebApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ERegistrarWebApiApplication.class, args);
    }

}
