package edu.mum.cs.cs425.demos.studentrecordsmgmtapp.LAB61;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
