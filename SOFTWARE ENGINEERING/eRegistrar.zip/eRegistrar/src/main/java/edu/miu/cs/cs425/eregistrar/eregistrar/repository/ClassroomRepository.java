package edu.miu.cs.cs425.eregistrar.eregistrar.repository;

import edu.miu.cs.cs425.eregistrar.eregistrar.model.Classroom;
import org.springframework.data.repository.CrudRepository;



public interface ClassroomRepository extends CrudRepository<Classroom, Integer> {

}
