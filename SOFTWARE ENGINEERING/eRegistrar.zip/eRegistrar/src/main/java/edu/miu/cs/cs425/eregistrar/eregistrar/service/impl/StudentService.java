package edu.miu.cs.cs425.eregistrar.eregistrar.service.impl;

import edu.miu.cs.cs425.eregistrar.eregistrar.model.Student;



public interface StudentService {
    Iterable<Student> getAllStudents();
}
