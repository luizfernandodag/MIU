package edu.mum.cs.cs425.finalexam.prodmgmt;

import java.time.LocalDate;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import edu.mum.cs.cs425.finalexam.prodmgmt.model.Product;

@SpringBootApplication
public class MyProductMgmtApp3Application implements CommandLineRunner {
	
	@Autowired
	private LocalContainerEntityManagerFactoryBean factory;

	public static void main(String[] args) {		
		SpringApplication.run(MyProductMgmtApp3Application.class, args);
	}

	@Override
	public void run(String... args) {
		System.out.println( "Starting ProductMgmtApp3..." );
		Product p = new Product(1001L, "Samsung Galaxy Note 4", 2500.0f, LocalDate.of(2017, 10, 31));
		saveProduct(p);
		System.out.println( "Finishing ProductMgmtApp3..." );
        System.out.printf( "Saved Product: { productId:%d, name:%s, unitPrice:%.2f, dateMfd:%s }\n",
        		p.getProductId(), p.getName(), p.getUnitPrice(), p.getDateMfd());
	}
	
    private void saveProduct(Product p) {
    	if (p != null) {
	        EntityManager em = factory.getObject().createEntityManager();
	        em.getTransaction().begin();
	        em.persist(p);
	        em.getTransaction().commit();
	        em.close();
    	}
    }
}
