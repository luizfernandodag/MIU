package edu.mum.cs.cs425.finalexam.prodmgmt;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import edu.mum.cs.cs425.finalexam.prodmgmt.model.Product;

public class ProductMgmtApp 
{
	private static final String PERSISTENCE_UNIT_NAME = "MyProductMgmtApp1PU";
    private static EntityManagerFactory factory;
    
    public ProductMgmtApp() {
    	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
    }
    
    public static void main( String[] args )
    {
    	Product p = null;
        System.out.println( "Starting the ProductMgmtApp..." );
        ProductMgmtApp app = new ProductMgmtApp();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/d");
        try {
			p = new Product(1001L, "Apple iPhone X", 1130.0f, sdf.parse("2017/12/01"));
		} catch (ParseException e) {			
			e.printStackTrace();
		}
        app.saveProduct(p);
        System.out.println( "Finishing the ProductMgmtApp..." );
        System.out.printf( "Saved Product: { productId:%d, name:%s, unitPrice:%.2f, dateMfd:%s }\n",
        		p.getProductId(), p.getName(), p.getUnitPrice(), sdf.format(p.getDateMfd()));
        
    }
    
    private void saveProduct(Product p) {
    	if (p != null) {
	        EntityManager em = factory.createEntityManager();
	        em.getTransaction().begin();
	        em.persist(p);
	        em.getTransaction().commit();
	        em.close();
	        factory.close();
    	}
    }
}
