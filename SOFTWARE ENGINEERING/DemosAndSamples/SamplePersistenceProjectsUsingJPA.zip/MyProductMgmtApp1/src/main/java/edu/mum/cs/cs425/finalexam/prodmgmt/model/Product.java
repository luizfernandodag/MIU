package edu.mum.cs.cs425.finalexam.prodmgmt.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="PRODUCTS")
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_id")
	private Long productId;
	
	@Column(name="product_number", nullable=false)
	private Long productNumber;
	
	@Column(name="name")
	private String name;
	
	@Column(name="unit_price")
	private Float unitPrice;
	
	@Column(name = "date_mfd")
	@Temporal(value=TemporalType.DATE)
	private Date dateMfd;
	
	public Product() {
		
	}
	
	public Product(long productNumber, String name, float unitPrice, Date dateMfd) {
		this.productNumber = productNumber;
		this.name = name;
		this.unitPrice = unitPrice;
		this.dateMfd = dateMfd;
	}
	
	public long getProductId() { return this.productId; }
	public long getProductNumber() { return this.productNumber; }
	public String getName() { return this.name; }
	public float getUnitPrice() { return this.unitPrice; }
	public Date getDateMfd() { return this.dateMfd; }
	
	public void setProductId(long productId) {
		this.productId = productId;
	}
	
	public void setProductNumber(long productNumber) {
		this.productNumber = productNumber;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public void setDateMfd(Date dateMfd) {
		this.dateMfd = dateMfd;
	}
}
