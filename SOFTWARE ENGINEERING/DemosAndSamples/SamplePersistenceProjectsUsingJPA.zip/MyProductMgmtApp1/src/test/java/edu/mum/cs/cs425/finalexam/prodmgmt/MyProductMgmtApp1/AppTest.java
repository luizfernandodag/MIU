package edu.mum.cs.cs425.finalexam.prodmgmt.MyProductMgmtApp1;

/**
 * Unit test for simple App.
 */
public class AppTest {
	
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        //
    }

}
