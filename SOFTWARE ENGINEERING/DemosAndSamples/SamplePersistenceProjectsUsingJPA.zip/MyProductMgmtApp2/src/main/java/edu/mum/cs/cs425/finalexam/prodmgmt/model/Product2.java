package edu.mum.cs.cs425.finalexam.prodmgmt.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCTS2")
public class Product2 {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long productId;
	
	@Column(name="ProductNumber", nullable=false)
	private long productNumber;
	
	@Column(name="Name")
	private String name;
	
	@Column(name="UnitPrice")
	private float unitPrice;
	
	@Column(name="DateMfd")
	private LocalDate dateMfd;
	
	@ManyToOne
	@JoinColumn(name = "SUPPLIERID", nullable = false)
	private Supplier supplier;
	
	public Product2() {
		
	}
	
	public Product2(long productNumber, String name, float unitPrice, LocalDate dateMfd, Supplier supplier) {
		this.productNumber = productNumber;
		this.name = name;
		this.unitPrice = unitPrice;
		this.dateMfd = dateMfd;
		this.supplier = supplier;
	}
	
	public long getProductId() { return this.productId; }
	public long getProductNumber() { return this.productNumber; }
	public String getName() { return this.name; }
	public float getUnitPrice() { return this.unitPrice; }
	public LocalDate getDateMfd() { return this.dateMfd; }
	
	public void setProductId(long productId) {
		this.productId = productId;
	}
	
	public void setProductNumber(long productNumber) {
		this.productNumber = productNumber;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public void setDateMfd(LocalDate dateMfd) {
		this.dateMfd = dateMfd;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	@Override
	public String toString() {
		return "Product2 [productId=" + productId + ", productNumber=" + productNumber + ", name=" + name
				+ ", unitPrice=" + unitPrice + ", dateMfd=" + dateMfd + ", supplier=" + supplier + "]";
	}
		
}
