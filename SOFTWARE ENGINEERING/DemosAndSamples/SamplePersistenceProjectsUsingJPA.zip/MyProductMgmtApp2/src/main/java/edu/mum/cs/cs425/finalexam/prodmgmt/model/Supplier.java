package edu.mum.cs.cs425.finalexam.prodmgmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Suppliers")
public class Supplier {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long supplierId;
	private long supplierNumber;
	private String name;
	
	@OneToMany(mappedBy = "supplier", cascade = CascadeType.PERSIST)
	private List<Product2> productsSupplied;
	
	public Supplier() {
		super();
	}

	public Supplier(long supplierNumber, String name) {
		super();
		this.supplierNumber = supplierNumber;
		this.name = name;
	}

	public long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(long supplierId) {
		this.supplierId = supplierId;
	}

	public long getSupplierNumber() {
		return supplierNumber;
	}

	public void setSupplierNumber(long supplierNumber) {
		this.supplierNumber = supplierNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Product2> getProductsSupplied() {
		return productsSupplied;
	}

	public void setProductsSupplied(List<Product2> productsSupplied) {
		this.productsSupplied = productsSupplied;
	}

	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", supplierNumber=" + supplierNumber + ", name=" + name + "]";
	}
	
}
