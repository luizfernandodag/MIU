package edu.mum.cs.cs425.finalexam.prodmgmt;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import edu.mum.cs.cs425.finalexam.prodmgmt.model.Product2;
import edu.mum.cs.cs425.finalexam.prodmgmt.model.Supplier;

public class ProductMgmtApp 
{
	private static final String PERSISTENCE_UNIT_NAME = "MyProductMgmtApp2";
    private static EntityManagerFactory factory;
    
    public ProductMgmtApp() {
    	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
    }
    
    public static void main( String[] args ) {
        System.out.println( "Starting ProductMgmtApp2..." );
        ProductMgmtApp app = new ProductMgmtApp();
        Supplier s1 = new Supplier(101, "Foxconn");
		Product2 p1 = new Product2(1001L, "Apple iPhone X", 1000.0f, LocalDate.of(2017, 12, 1), s1);
		Product2 p2 = new Product2(1002L, "Apple iPad Mini", 1200.0f, LocalDate.of(2018, 5, 31), s1);
        List<Product2> products = Arrays.asList(new Product2[] { p1, p2 });
        s1.setProductsSupplied(products);
		app.saveSupplierAndProducts(s1);
        System.out.printf( "Saved Product: { productId:%d, name:%s, unitPrice:%.2f, dateMfd:%s }\n",
        		p1.getProductId(), p1.getName(), p1.getUnitPrice(), p1.getDateMfd());
        System.out.printf( "Saved Product: { productId:%d, name:%s, unitPrice:%.2f, dateMfd:%s }\n",
        		p2.getProductId(), p2.getName(), p2.getUnitPrice(), p2.getDateMfd());
        System.out.println( "Finishing ProductMgmtApp2..." );
    }
    
    private void saveSupplierAndProducts(Supplier s) {
    	if (s != null) {
	        EntityManager em = factory.createEntityManager();
	        em.getTransaction().begin();
	        em.persist(s);
	        em.getTransaction().commit();
	        em.close();
	        factory.close();
    	}
    }
}
