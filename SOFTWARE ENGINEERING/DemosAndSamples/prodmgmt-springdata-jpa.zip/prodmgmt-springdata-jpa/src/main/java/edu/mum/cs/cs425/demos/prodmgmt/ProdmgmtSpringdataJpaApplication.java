package edu.mum.cs.cs425.demos.prodmgmt;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.cs.cs425.demos.prodmgmt.model.Product;
import edu.mum.cs.cs425.demos.prodmgmt.repository.ProductRepository;

@SpringBootApplication
public class ProdmgmtSpringdataJpaApplication implements CommandLineRunner {
	
	@Autowired
	private ProductRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(ProdmgmtSpringdataJpaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
//		Product p = new Product(10001L, "Samsung Galaxy 10", 1600.00f, LocalDate.of(2018, 5, 31));
//		Product savedProduct = saveProduct(p);
//		System.out.println(savedProduct);
		for(Product p : getSpecialProducts()) {
			System.out.println(p);
		}
	}
	
	Product saveProduct(Product p) {
		return repository.save(p);
	}
	
	List<Product> getSpecialProducts() {
		return repository.findProductsByUnitPriceGreaterThan(1500.00f);
	}

}
