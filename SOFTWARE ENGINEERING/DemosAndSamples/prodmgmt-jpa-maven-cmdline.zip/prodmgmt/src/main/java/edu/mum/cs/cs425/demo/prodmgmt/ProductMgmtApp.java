package edu.mum.cs.cs425.demo.prodmgmt;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import edu.mum.cs.cs425.demo.prodmgmt.model.Product;

/**
 * Hello JPA world!
 *
 */
public class ProductMgmtApp 
{
	private static final String PERSISTENT_UNIT_NAME = "MyProductMgmtApp1PU";
	
	private static EntityManagerFactory emf;
	
	public ProductMgmtApp() {
		this.emf = Persistence.createEntityManagerFactory(PERSISTENT_UNIT_NAME);
	}
	
    public static void main( String[] args )
    {
        System.out.println( "Hello JPA World!" );
        ProductMgmtApp app = new ProductMgmtApp();
        Product p = new Product(1001L, "Apple iPhone X", 1500.00f, LocalDate.of(2018, 10, 24));
        app.saveProduct(p);
        System.out.printf("Saved Product: {productNo:%d, name:%s}", p.getProductNumber(), p.getName());
    }
    
    private void saveProduct(Product p) {
    	if(p != null) {
    		EntityManager em = emf.createEntityManager();
    		em.getTransaction().begin();
    		em.persist(p);
    		em.getTransaction().commit();
    		em.close();
    		emf.close();
    	}
    }
}
