package edu.miu.cs.cs425.lesson11.mybooksmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybooksmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybooksmgmtApplication.class, args);
	}

}
