package edu.miu.cs.cs425.lesson11.mybooksmgmt.service;

import edu.miu.cs.cs425.lesson11.mybooksmgmt.model.Publisher;

public interface PublisherService {

    Iterable<Publisher> getAllPublishers();

}
