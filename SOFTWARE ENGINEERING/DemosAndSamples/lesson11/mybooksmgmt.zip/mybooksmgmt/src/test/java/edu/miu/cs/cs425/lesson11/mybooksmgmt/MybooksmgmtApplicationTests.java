package edu.miu.cs.cs425.lesson11.mybooksmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybooksmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
